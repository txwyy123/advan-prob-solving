#include <stdio.h>
#include <iostream>

using namespace std;

int main(){
	int money = 2000;
	int changes[4] = {10,100,1000,10000};
	int values[4] = {1, 5, 10, 25};
	int dp[4][money+1];

	for(int i = 0; i < 4; i++)
		for(int j = 0; j < money+1; j++)
			dp[i][j] = -1;


	for(int i = 0; i < money+1 && i <= changes[0]; i++)
		dp[0][i] = i;

	for(int i = 1; i < 4; i++){
		for(int j = 1; j <= changes[i]; j++)
			for(int k = 0; k < money+1; k++)
				for(int m = 1; m <= i; m++){
					if(k >= values[i]*j && dp[i-m][k-values[i]*j] != -1)
						dp[i][k] = max(dp[i][k], dp[i-m][k-values[i]*j]+j);
				}
	}

	cout<<"input:"<<endl<<changes[0]<<"p "<<changes[1]<<"n "<<changes[2]<<"d "<<changes[3]<<"q "<<money<<endl;
	cout<<"output:"<<endl<<"the maximum number of coins is "<<dp[3][money]<<endl;
}
