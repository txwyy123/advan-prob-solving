#include "countChar.h"

int main(){
	doCount();
	return 0;
}