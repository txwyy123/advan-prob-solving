#ifndef COUNT_CHAR_H
#define COUNT_CHAR_H

void doCount();

#endif